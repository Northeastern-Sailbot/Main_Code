Test encoder viability on custom gearboxes
Contains appropriate code for detecting RPM, RPS, and distance traveled.